/*
  Copyright @ 1999 ImageMagick Studio LLC, a non-profit organization
  dedicated to making software imaging solutions freely available.

  You may not use this file except in compliance with the License.  You may
  obtain a copy of the License at

    https://imagemagick.org/license/

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/

#include "coders/coders-private.h"

#define MagickSVGHeaders \
  MagickExtendedCoderHeader("SVG", 1, "?XML", MagickTrue) \
  MagickExtendedCoderHeader("SVG", 1, "?xml", MagickTrue) \
  MagickExtendedCoderHeader("SVG", 1, "SVG", MagickTrue) \
  MagickExtendedCoderHeader("SVG", 1, "svg", MagickTrue)

#define MagickSVGAliases \
  MagickCoderAlias("SVG", "SVGZ") \
  MagickCoderAlias("SVG", "RSVG") \
  MagickCoderAlias("SVG", "MSVG")

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

MagickCoderExports(SVG)

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
